import boto3
import datetime
from dateutil.relativedelta import relativedelta


def get_hourly_cost_data(start_date, end_date):
    """
    Retrieves hourly cost data from AWS Cost Explorer API.

    Args:
      start_date (datetime): Start date of the billing period.
      end_date (datetime): End date of the billing period.

    Returns:
      list: List of dictionaries containing hourly cost data.
    """
    client = boto3.client("ce")
    paginator = client.get_paginator("get_cost_and_usage")
    response_iterator = paginator.paginate(
        TimePeriod={"Start": start_date.isoformat(), "End": end_date.isoformat()},
        Granularity="HOURLY",
    )
    cost_data = []
    for page in response_iterator:
        cost_data.extend(page["ResultsByTime"])
    return cost_data


if __name__ == "__main__":
    # Define timeframe
    today = datetime.datetime.utcnow()
    start_date = today - relativedelta(days=7)
    end_date = today

    # Retrieve cost data
    hourly_data = get_hourly_cost_data(start_date, end_date)

    # Print data (modify as needed)
    for hour in hourly_data:
        print(f"Time: {hour['TimePeriod']['Start']} - Cost: {hour['Total']['Amount']}")
