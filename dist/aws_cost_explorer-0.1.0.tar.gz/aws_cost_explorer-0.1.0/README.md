A simple python cli to get aws cost data.

###TODO
1. see code todos
2. get profile override from env


    
